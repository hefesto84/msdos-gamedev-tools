#include <fcntl.h>
#include <stdio.h>
#include <conio.h>



main(int argc, char *argv[])

{ float AT,LQ;
  FILE *f1,
       *f2,
       *f3;
  char FN1[20],
       FN2[20],
       FN3[20];
  char Temp1[20],
       Temp2[20];
  char ch;
  long sizef;

  strcpy(Temp1,argv[1]);
  strcpy(Temp2,".BIN");
  strcat(Temp1,Temp2);
  strcpy(FN1,Temp1);
  if ((f1=fopen(FN1,"r+b"))==NULL)
  { printf("Not able to open %s\n",FN1);
    exit(0);
  }

/*  for (count = 0; count < 512; count++)
    fgetc(f1);
*/
  strcpy(Temp1,argv[1]);
  strcat(Temp1,".LOW");
  strcpy(FN2,Temp1);
  if((f2=fopen(FN2,"w+b"))==NULL)
  { printf("cannot open file %s\n",FN2);
    exit(0);
  }

  strcpy(Temp1,argv[1]);
  strcat(Temp1,".HIG");
  strcpy(FN3,Temp1);
  if((f3=fopen(FN3,"w+b"))==NULL)
  { printf("cannot open file  %s\n",FN3);
    exit(0);
  }


while(!(feof(f1)))
{ ch = fgetc(f1);
  fprintf(f2,"%c",ch);
  if (!(feof(f1)))
  { ch = fgetc(f1);
    fprintf(f3,"%c",ch);
  }
}
  fclose(f1);
  fclose(f2);
  fclose(f3);
}
