/* simpwin9 copyright 1995 - 1997 by bruce r. o'banion */

# include <string.h>
# include <stdarg.h>
# include <conio.h>
# include <stdlib.h>
# include <dir.h>
# include <dos.h>
# include <bios.h>
# include <stdio.h>

# include "simpwn92.h"

int deinstall(int install_drive,char *path);
int install(int install_drive,char *path);

void main(int argc,char *argv[])
{
	char drive[2];
	int install_drive;
	int error = 0;
	int done = 0;
	char choice[3] = "1";
	char path[256];
	char *temp_point;

	system("CLS");
	strcpy(path,argv[1]);
	if((path[0] == 0x00) | (path[2] != '\\'))
	{
		cprintf("Comand instal92 [drive:\\path]");
		exit(1);
	}
	temp_point = strrchr(path,'\\');
	if(temp_point[1] == 0x00)
	{
		temp_point[0] = 0x00;
	}
	install_drive = getdisk();
	if(init_window(3,1,drive) != 0)
	{
		cprintf("Can't init SIMPWIN92 !");
		exit(1);
	}
	simp_window(1,1,80,25,1,0,14,1,0,0,0,0,0);
	write_window((80 - strlen(" HIT ANY KEY ")) / 2,25," HIT ANY KEY ");
	read_text("install.scr",2);
	popup_window(1,31,8,49,13,2,1,15,1,1,8,0,0,0);
	write_window(3,2,"1\) Install");
	write_window(3,3,"2\) Deinstall");
	write_window(3,5,"Choice ?");
	save_screen(0);
	while(done == 0)
	{
		show_cursor();
		if(get_string(choice," ","9",12,5,1,1) != 0)
		{
			popup_window(2,25,10,55,12,2,1,14,4,1,8,0,0,0);
			write_window(3,2,"Install/Deinstall Aborted!");
			delay(1000);
			unpopup_window(2);
			error = 1;
			done = 1;
		}
		else
		{
			switch(atoi(choice))
			{
				case 1 : error = install(install_drive,argv[1]);
						done = 1;
						break;
				case 2 : error = deinstall(install_drive,argv[1]);
						done = 1;
						break;
			}
		}
		hide_cursor();
	}
	load_screen(0);
	unpopup_window(1);
	if(error == 1)
	{
		popup_window(2,25,10,55,12,2,1,14,4,1,8,0,0,0);
		write_window(3,2,"Install/Deinstall Error !");
		delay(1000);
	}
	else
	{
		popup_window(2,20,10,60,13,2,1,15,1,1,8,0,0,0);
		if(atoi(choice) == 1)
		{
			write_window((41 - strlen("Install complete !")) / 2,2,"Install complete !");
		}
		else
		{
			write_window((41 - strlen("Deinstall complete !")) / 2,2,"Denstall complete !");
		}
		write_window((41 - strlen(" HIT ANY KEY ")) / 2,4," HIT ANY KEY ");
		bioskey(0);
	}
	unpopup_window(2);
	uninit_window();
	system("CLS");
	show_cursor();
}

int install(int install_drive,char *path)
{
	char drive[2];
	char *temp_point;
	char buff[256];
	int error = 0,i = 0,count = 0;
	unsigned long int start = 0L;
	char make_direc[20][20];
	char current_direc[256];

	getcwd(current_direc,255);
	system("CLS");
	drive[0] = path[0];
	drive[1] = 0x00;
	strupr(drive);
	strcpy(buff,path);
	temp_point = strtok(buff,"\\");
	while(temp_point != NULL)
	{
		strcpy(make_direc[count],temp_point);
		temp_point = strtok(NULL,"\\");
		count++;
	}
	setdisk(drive[0] - 65);
	chdir("\\");
	for(i = 1;i < count;i++)
	{
		mkdir(make_direc[i]);
		chdir(make_direc[i]);
	}
	setdisk(install_drive);
	chdir(current_direc);
	buff[0] = 0x00;
	while((error = read_file(buff,"install.lst",256,start)) < 1)
	{
		if(buff[0] == 0x00)
		{
			break;
		}
		temp_point = strtok(buff,"\r\n");
		start = strlen(temp_point) + 2 + start;
		strcat(buff," ");
		strcat(buff,path);
		system(buff);
		buff[0] = 0x00;
	}
	if(error > 0)
	{
		return(1);
	}
	return(0);
}


int deinstall(int install_drive,char *path)
{
	char drive[2];
	char buff[256];
	char *temp_point;
	char remove_path[20][20];
	int error = 0;
	int count = 1;
	int i;
	unsigned long int start = 0L;
	char current_direc[256];
	char temp_path[256];

	strcpy(temp_path,path);
	getcwd(current_direc,255);
	drive[0] = path[0];
	drive[1] = 0x00;
	strupr(drive);
	while((error = read_file(buff,"deinstall.lst",256,start)) < 1)
	{
		if(buff[0] == 0x00)
		{
			break;
		}
		setdisk(drive[0] - 65);
		chdir(path);
		temp_point = strtok(buff,"\r\n");
		start = strlen(temp_point) + 2 + start;
		if(remove(buff) != 0)
		{
			error = 1;
			setdisk(install_drive);
			break;
		}
		buff[0] = 0x00;
		setdisk(install_drive);
		chdir(current_direc);
	}
	if(error < 1)
	{
		temp_point = strtok(path,"\\");
		while(temp_point != NULL)
		{
			strcpy(remove_path[count],temp_point);
			temp_point = strtok(NULL,"\\");
			count++;
		}
		setdisk(drive[0] - 65);
		chdir(temp_path);
		for(i = (count - 1);i > 0;i--)
		{
			chdir("..");
			rmdir(remove_path[i]);
		}
		setdisk(install_drive);
		chdir(current_direc);
	}
	else
	{
		return(1);
	}
	return(0);
}

