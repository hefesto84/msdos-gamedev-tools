# include <string.h>
# include <conio.h>
# include <alloc.h>
# include <stdlib.h>
# include <stdio.h>
# include <io.h>
# include <sys/stat.h>
# include <dir.h>
# include <dos.h>

int dev_error;
FILE *t_fp;

int read_file(void *buff,char *file_name,unsigned int length,unsigned long int byte_start);
int handler(int errval,int ax,int bp,int si);
int write_file(void *buff,char *file_name,unsigned int length,unsigned long int byte_start);
int error_write(FILE *err_pt);
int creat_file(char *file_name);
int read_directory(char *buff,int num_file,char *directory);

void main(void)
{
	char *buff;
	char *direc;
	int i,j,k;
	int error = 0;
	int skip= 0;
	char *temp_point;
	char pack_path[80];
	char deinstall[20];
	char deinst_path[80];
	char title[80];
	unsigned long int start = 0L;
	unsigned long int pack_start = 0L;
	unsigned long int deinst_start = 0L;
	char check[8][20] = {"","","VOLUME IN","VOLUME SERIAL","DIRECTORY",
			     "<DIR>","FILE\(S\)","BYTES FREE"};


	system("CLS");
	harderr(handler);
	if((buff = (char*)malloc(257)) == NULL)
	{
		error = 1;
	}
	else
	{
		if((direc = (char*)malloc(80 * 13)) == NULL)
		{
			error = 1;
			free(buff);
		}
	}
	if(error == 1)
	{
		cprintf("Not enough memory!");
		exit(1);
	}
	memset(buff,0,257);
	memset(direc,0,80 * 14);
	if(read_directory(direc,80,"*.txt") != 0)
	{
		cprintf("No files found!");
		free(buff);
		free(direc);
		exit(1);
	}
	i = 0;
	strcpy(pack_path,"packing.lst");
	strcpy(deinst_path,"deinstal.lst");
	creat_file(pack_path);
	creat_file(deinst_path);
	while(direc[i * 13] != 0x00)
	{
		strcpy(check[0],&direc[i * 13]);
		strtok(check[0],".");
		for(j = strlen(check[0]);j < 13;j++)
		{
			check[0][j] = 0x20;
			switch(j)
			{
				case 9 : check[0][9] = 'T'; break;
				case 10 : check[0][10] = 'X'; break;
				case 11 : check[0][11] = 'T'; break;
				case 12 : check[0][12] = ''; break;
			}
		}
		strcpy(check[1],&direc[i * 13]);
		strtok(check[1],".");
		strcat(check[1],".ZIP");
		strcpy(title,"\r\nFiles in ");
		strcat(title,check[1]);
		strcat(title,":\r\n\r\n");
		error = write_file(title,pack_path,strlen(title),pack_start);
		if(error > 0)
		{
			break;
		}
		pack_start = pack_start + strlen(title);
		strtok(check[1],".");
		for(j = strlen(check[1]);j < 13;j++)
		{
			check[1][j] = 0x20;
			switch(j)
			{
				case 9 : check[1][9] = 'Z'; break;
				case 10 : check[1][10] = 'I'; break;
				case 11 : check[1][11] = 'P'; break;
				case 12 : check[1][12] = ''; break;
			}
		}
		start = 0L;
		skip = 0;
		while((error = read_file(buff,&direc[i * 13],256,start)) < 1)
		{
			if(buff[0] == 0x00)
			{
				break;
			}
			temp_point = strchr(buff,'\r');
			temp_point[0] = 0x00;
			for(k = 1;k < 256;k++)
			{
				if((temp_point[k] != '\r') & (temp_point[k] != '\n'))
				{
					break;
				}
			}
			start = start + strlen(buff) + k;
			strupr(buff);
			if(strcmp(buff,"") == 0)
			{
				skip = 1;
			}
			for(j = 0;j < 8;j++)
			{
				if(strstr(buff,check[j]) != NULL)
				{
					skip = 1;
				}
			}
			if(skip != 1)
			{
				strcat(buff,"\r\n");
				if((error = write_file(buff,pack_path,strlen(buff),pack_start)) == 0)
				{
					pack_start = pack_start + strlen(buff);
					temp_point = strtok(buff," ");
					strcpy(deinstall,temp_point);
					strcat(deinstall,".");
					temp_point = strtok(NULL," ");
					strcat(deinstall,temp_point);
					strcat(deinstall,"\r\n");
					if((error = write_file(deinstall,deinst_path,strlen(deinstall),deinst_start)) == 0)
					{
						deinst_start = deinst_start + strlen(deinstall);
					}
				}
			}
			skip = 0;
			memset(buff,0,256);
			if(error > 0)
			{
				break;
			}
		}
		if(error > 0)
		{
			break;
		}
		i++;
	}
	if(error > 0)
	{
		cprintf("File error file %s!",&direc[i * 13]);
	}
	free(buff);
	free(direc);
}

int read_file(void *buff,char *file_name,unsigned int length,unsigned long int byte_start)
{
	FILE r_fp;

	dev_error = 0;
	t_fp = &r_fp;
	if((t_fp = fopen(file_name,"r+b")) == NULL)
	{
		error_write(t_fp);
		return(dev_error);
	}
	if(fseek(t_fp,byte_start,0) != 0)
	{
		error_write(t_fp);
		fclose(t_fp);
		return(dev_error);
	}
	if(fread(buff,sizeof(char) * length,1,t_fp) != 1)
	{
		error_write(t_fp);
		fclose(t_fp);
		return(dev_error);
	}
	fclose(t_fp);
	return(0);
}

#pragma warn -par

int handler(int errval,int ax,int bp,int si)
{
	if(ax < 0)
	{
		dev_error = _DI & 0x00ff;
		bdosptr(0x09,"$",0);
		hardretn(2);
	}
	dev_error = errval;
	bdosptr(0x09,"$",0);
	hardretn(2);
	return(0);
}

int write_file(void *buff,char *file_name,unsigned int length,unsigned long int byte_start)
{
	FILE w_fp;

	dev_error = 0;
	t_fp = &w_fp;
	if((t_fp = fopen(file_name,"r+b")) == NULL)
	{
		error_write(t_fp);
		return(dev_error);
	}
	if(fseek(t_fp,byte_start,0) != 0)
	{
		error_write(t_fp);
		fclose(t_fp);
		return(dev_error);
	}
	if(fwrite(buff,sizeof(char) * length,1,t_fp) != 1)
	{
		error_write(t_fp);
		fclose(t_fp);
		return(dev_error);
	}
	fclose(t_fp);
	return(0);
}

int error_write(FILE *err_pt)
{
	if(dev_error == 0)
	{
		dev_error = _doserrno;
	}
	if(feof(err_pt) != 0)
	{
		dev_error = -1;
		return(1);
	}
	return(0);
}

int creat_file(char *file_name)
{
	int handle;

	if(access(file_name,0) != 0)
	{
		handle = creat(file_name,S_IREAD|S_IWRITE);
		close(handle);
		return(1);
	}
	else
	{
		return(0);
	}
}

int read_directory(char *buff,int num_file,char *directory)
{
	int i;
	char far *data;
	struct ffblk dir_data;


	data = getdta();
	dev_error = 0;
	if(findfirst(directory,&dir_data,FA_RDONLY) != 0)
	{
		return(1);
	}
	strcpy(buff,dir_data.ff_name);
	buff = buff + 13;
	for(i = 1;i < num_file;i++)
	{
		if(findnext(&dir_data) != 0)
		{
			break;
		}
		strcpy(buff,dir_data.ff_name);
		buff = buff + 13;
	}
	setdta(data);
	return(0);
}

