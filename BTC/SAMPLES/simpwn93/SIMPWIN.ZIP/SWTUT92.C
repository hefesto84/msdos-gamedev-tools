/*  simpwin9 copyright 1995 - 1997 by bruce r. o'banion */

# include <dos.h>
# include <string.h>
# include <stdio.h>
# include <bios.h>
# include <stdlib.h>
# include <conio.h>
# include <mem.h>
# include <sys\stat.h>
# include <io.h>
/***************************************************************************

						simple windows includes

***************************************************************************/

# include "simpwn92.h"
# include "mouse92.h"
# include "skdef92.h"

/***************************************************************************

						window call defines

***************************************************************************/

# define MAIN_WIN 1
# define DEMO_WIN 2
# define TEXT_WIN 3
# define FONT_TEXT 4
# define FONT_WIN 5
# define QUIT_WIN 6
# define FUNG_WIN 7
# define DEMO_TEXT 8
# define ENTER_WIN 9
# define EDIT_WIN 10

/***************************************************************************

	fungtion prototypes

***************************************************************************/

int font_demo(void);
int main_menu(void);
int quit(void);
int demo_menu(void);
int tutor_menu(void);
int tut_menu(void);
int demo_popup(void);
int shad_demo(void);
int boarder_demo(void);
int enter_demo(void);
void reed_text(char *file_name);
int read_text_demo(void);
int mou_menu(void);

int display_switch = 1;
char font_string[50];
int mou_switch;

void main(void)
{
	int i,j,k;

/***************************************************************************
	initialize simpwin9 and mou105
****************************************************************************/
	init_window(12,5,"");
	strcpy(font_string,"lfsw92 medieval.fnt");
	system(font_string);
	hide_cursor();
	system("cls");
	if(mouinstalled())
	{
		moureset();
		mouhide();
		mousetposition(1,1);
		mou_switch = 1;
		simp_window(30,10,50,12,1,0,14,4,0,0,0,0,0);
		write_window(3,2,"Mouse Installed !");
		delay(1000);
	}
	k= 3;
	for(i = 0;i < 13;i++)
	{
		for(j = k - 3;j < k;j++)
		{
			simp_window(40 - j,13 - i,40 + j,13 + i,1,0,14,4,0,0,0,0,0);
		}
		k = k + 3;
	}
	simp_window(1,1,80,25,1,0,14,4,0,0,0,0,0);
	read_text("title.scr",3);
	save_screen(1);

/****************************************************************************

	run program menu system

***************************************************************************/
	moucursortype(0x02);
	moushow();
	/*mou_switch = 0;*/
	while(main_menu())
	{
	}

/***************************************************************************

	uninitialize simpwin9 and mou105 and exit and restore font

****************************************************************************/

	uninit_window();
	moureset();
	show_cursor();
	system("lfsw92 ibmstd.fnt");
	system("cls");
}

/**************************************************************************

	This is a typical menu fungtion. I will comment this one only
	to save on redundancy. All the other menuing moduals are similar.

**************************************************************************/

int font_demo(void)
{
	int i,choice = -1,old_i = 9,moux = 0,mouy = 0;
	char lable[8][13] = {"ROMan","SCRipt","ANTique","BROdway","SANserif",
		"COUrrier","MEDieval","IBM std vga"};

/**************************************************************************

	draw window and menu with hilght

**************************************************************************/
	popup_window(FONT_TEXT,20,5,65,14,2,2,14,6,1,8,0,0,0);
	write_window(16,10," HIT ANY KEY ");
	read_text("font.txt",2);
	popup_window(FONT_WIN,30,6,45,15,2,2,14,6,1,8,0,0,0);
	write_window(5,1," FONTS ");
	read_text("font.men",3);
	textcolor(0);
	write_window(3,2,"R");
	write_window(3,3,"S");
	write_window(3,4,"A");
	write_window(3,5,"B");
	write_window(5,6,"N");
	write_window(3,7,"C");
	write_window(3,8,"M");
	write_window(3,9,"I");
	save_screen(0);
/***************************************************************************

	This is the cursor and mouse control

***************************************************************************/

	i = 0;
	moushow();
	for(;;)
	{
		choice = 0;
	/******************************************************************

		This tells where is mouse

	******************************************************************/
		if(mouposition(&moux,&mouy))
		{
			if((moux > 30 ) & (moux < 45 ))
			{
				i = mouy - 7;
			}
		}
	/******************************************************************

		this is for cursor control

	******************************************************************/

		if(i < 0)
		{
			i = 0;
		}
		if(i > 7)
		{
			i = 7;
		}
	/******************************************************************

		This checks for key entery

	******************************************************************/

		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 10; break;
				case ENTER : choice = 1; break;
				case CURSOR_UP : i = i - 1; break;
				case CURSOR_DN : i = i + 1; break;
				case ALT_R : choice = 2; break;
				case ALT_S : choice = 3; break;
				case ALT_A : choice = 4; break;
				case ALT_B : choice = 5; break;
				case ALT_N : choice = 6; break;
				case ALT_C : choice = 7; break;
				case ALT_M : choice = 8; break;
				case ALT_I : choice = 9; break;
			}
		}


	/******************************************************************

		this draws shadowed hilight

	********************************************************************/

		if(old_i != i)
		{
			old_i = i;
			mouhide();
			load_screen(0);
			simp_window(31,7 + i,44,7 + i,0,2,4,3,1,8,0,0,0);
			write_window(2,1,"%s",lable[i]);
			moushow();
		}

	/******************************************************************

		this checks mouse button

	******************************************************************/

		if(moubuttonpressed(LEFTBUTTON))
		{
			if((moux < 45) & (moux > 30) & (mouy > 6) & (mouy < 15))
			{
				choice = 1;
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);

/************************************************************************

	this check to see if there is a selection

************************************************************************/

	if(choice == 1)
	{
		choice = i + 2;
	}
	switch(choice)
	{
		case 2 : strcpy(font_string,"lfsw92 roman.fnt"); break;
		case 3 : strcpy(font_string,"lfsw92 script.fnt"); break;
		case 4 : strcpy(font_string,"lfsw92 antique.fnt"); break;
		case 5 : strcpy(font_string,"lfsw92 brodway.fnt"); break;
		case 6 : strcpy(font_string,"lfsw92 sanserif.fnt"); break;
		case 7 : strcpy(font_string,"lfsw92 courrier.fnt"); break;
		case 8 : strcpy(font_string,"lfsw92 medieval.fnt"); break;
		case 9 : strcpy(font_string,"lfsw92 ibmstd.fnt"); break;
	}
	system(font_string);
	unpopup_window(FONT_WIN);
	unpopup_window(FONT_TEXT);
	display_switch = 0;
	hide_cursor();
	return(0);
}

int main_menu(void)
{
	int pick,choice,i = 0,old_i = 9,moux = 0,mouy = 0;
	char lable[4][13] = {"Demo","Text","Fonts","eXit"};

/***************************************************************************

	this code is used to get rid of window flash

**************************************************************************/
	if(display_switch)
	{
		load_screen(1);
		popup_window(MAIN_WIN,5,3,52,5,2,2,14,6,1,8,0,0,0);
		read_text("main.men",3);
		save_screen(2);
	}
	else
	{
		load_screen(2);
	}

/**************************************************************************/

	display_switch = 1;
	textcolor(0);
	write_window(3,2,"D");
	write_window(15,2,"T");
	write_window(28,2,"F");
	write_window(43,2,"X");
	save_screen(0);
	i = 0;
	moushow();
	for(;;)
	{
		choice = 0;
		if(mouposition(&moux,&mouy))
		{
			if(mouy == 4)
			{
				if((moux > 5) & (moux < 11))
				{
					i = 0;
				}
				else if((moux > 17) & (moux < 24))
				{
					i = 1;
				}
				else if((moux > 30) & (moux < 39))
				{
					i = 2;
				}
				else if((moux > 44) & (moux < 50))
				{
					i = 3;
				}
			}
		}
		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 6; break;
				case CURSOR_RIGHT : i = i + 1; break;
				case CURSOR_LEFT : i = i - 1; break;
				case ENTER : choice = 1; break;
				case ALT_D : choice = 2; break;
				case ALT_T : choice = 3; break;
				case ALT_X : choice = 5; break;
				case ALT_F : choice = 4; break;
			}
		}
		if(i < 0)
		{
			i = 0;
		}
		if(i > 3)
		{
			i = 3;
		}

		if(old_i != i)
		{
			mouhide();
			old_i = i;
			load_screen(0);
			switch(i)
			{
				case 0 : simp_window(6,4,11,4,0,2,4,3,1,8,0,0,0); break;
				case 1 : simp_window(18,4,24,4,0,2,4,3,1,8,0,0,0); break;
				case 2 : simp_window(31,4,39,4,0,2,4,3,1,8,0,0,0); break;
				case 3 : simp_window(45,4,50,4,0,2,4,3,1,8,0,0,0); break;
			}
			write_window(2,1,"%s",lable[i]);
			moushow();
		}
		if(moubuttonpressed(0))
		{
			if(mouy == 4)
			{
				if(((moux > 5) & (moux < 11)) |
					((moux > 17) & (moux < 24)) |
					((moux > 30) & (moux < 39)) |
					((moux > 44) & (moux < 50)))
				{
					choice = 1;
				}
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);
	if(choice == 1)
	{
		choice = i + 2;
	}
	pick = 1;
	switch(choice)
	{
		case 2 : while(demo_menu()){} break;
		case 3 : while(tutor_menu()){} break;
		case 4 : font_demo(); break;
		case 6 :
		case 5 : pick = quit(); break;
	}
	return(pick);
}

/*************************************************************************

	this modual ask if you are shure you wish to quit

************************************************************************/

int quit(void)
{
	int pick = 1;
	char choice[2] = "N";

	show_cursor();
	popup_window(QUIT_WIN,32,10,48,12,1,2,15,4,1,8,0,0,0);
	write_window(3,2,"Quit Y/N ?");
	get_string(choice," ","Y",14,2,1,1);
	strupr(choice);
	hide_cursor();
	if(strcmp(choice,"Y") == 0)
	{
		pick = 0;
	}
	unpopup_window(QUIT_WIN);
	return(pick);
}

int demo_menu(void)
{
	int pick,choice,i = 0,old_i = 7 ,moux = 0,mouy = 0;
	char lable[5][13] = {"Capacity","Shadow","Boarder","Enteries","Read text"};

	if(display_switch)
	{
		load_screen(2);
		popup_window(DEMO_WIN,7,4,19,10,2,2,14,6,1,8,0,0,0);
		read_text("demo.men",3);
		save_screen(3);
	}
	else
	{
		load_screen(3);
	}
	display_switch = 1;
	textcolor(0);
	write_window(3,2,"C");
	write_window(3,3,"S");
	write_window(3,4,"B");
	write_window(3,5,"E");
	write_window(3,6,"R");
	save_screen(0);
	i = 0;
	moushow();
	for(;;)
	{
		choice = 0;
		if(mouposition(&moux,&mouy))
		{
			if((moux > 7) & (moux < 19))
			{
				i = mouy - 5;
			}
		}
		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 7; break;
				case CURSOR_DN : i = i + 1; break;
				case CURSOR_UP : i = i - 1; break;
				case ENTER : choice = 1; break;
				case ALT_C : choice = 2; break;
				case ALT_S : choice = 3; break;
				case ALT_B : choice = 4; break;
				case ALT_E : choice = 5; break;
				case ALT_R : choice = 6; break;
			}
		}
		if(i < 0)
		{
			i = 0;
		}
		if(i > 4)
		{
			i = 4;
		}
		if(old_i != i)
		{
			old_i = i;
			mouhide();
			load_screen(0);
			simp_window(8,5 + i,18,5 + i,0,2,4,3,1,8,0,0,0);
			write_window(2,1,"%s",lable[i]);
			moushow();
		}
		if(moubuttonpressed(LEFTBUTTON))
		{
			if((moux > 7) & (moux < 19) & (mouy > 4) & (mouy < 10))
			{
				choice = 1;
			}
			else
			{
				choice = 7;
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);
	pick = 1;
	if(choice == 1)
	{
		choice = i + 2;
	}
	switch(choice)
	{
		case 2 : demo_popup(); break;
		case 3 : shad_demo(); break;
		case 4 : boarder_demo(); break;
		case 5 : enter_demo(); break;
		case 6 : read_text_demo(); break;
		case 7 : pick = 0; break;
	}
	display_switch = 0;
	return(pick);
}

int tutor_menu(void)
{
	int pick,choice,i = 0,old_i = 12,moux = 0,mouy = 0;
	char lable[7][13] = {"Genral info","Disclaimer",
		"Functions","Support","Mouse91","Loadfonts","simply sOft"};

	if(display_switch)
	{
		load_screen(2);
		popup_window(TEXT_WIN,17,4,32,12,2,2,14,6,1,8,0,0,0);
		read_text("tutor.men",3);
		save_screen(3);
	}
	else
	{
		load_screen(3);
	}
	display_switch = 1;
	textcolor(0);
	write_window(3,2,"G");
	write_window(3,3,"D");
	write_window(3,4,"F");
	write_window(3,5,"S");
	write_window(3,6,"M");
	write_window(3,7,"L");
	write_window(11,8,"O");
	save_screen(0);
	moushow();
	for(;;)
	{
		choice = 0;
		if(mouposition(&moux,&mouy))
		{
			if((moux > 17) & (moux < 32))
			{
				i = mouy - 5;
			}
		}
		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 10; break;
				case CURSOR_DN : i = i + 1; break;
				case CURSOR_UP : i = i - 1; break;
				case ENTER : choice = 1; break;
				case ALT_G : choice = 2; break;
				case ALT_D : choice = 3; break;
				case ALT_F : choice = 4; break;
				case ALT_S : choice = 5; break;
				case ALT_M : choice = 6; break;
				case ALT_V : choice = 7; break;
				case ALT_O : choice = 8; break;
			}
		}
		if(i < 0)
		{
			i = 0;
		}
		if(i > 6)
		{
			i = 6;
		}
		if(old_i != i)
		{
			old_i = i;
			mouhide();
			load_screen(0);
			simp_window(18,5 + i,31,5 + i,0,2,4,3,1,8,0,0,0);
			write_window(2,1,"%s",lable[i]);
			moushow();
		}
		if(moubuttonpressed(LEFTBUTTON))
		{
			if((moux > 17) & (moux < 32) & (mouy > 4) & (mouy < 12))
			{
				choice = 1;
			}
			else
			{
				choice = 10;
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);
	pick = 1;
	if(choice == 1)
	{
		choice = i + 2;
	}
	switch(choice)
	{
		case 2 : reed_text("genral.txt"); break;
		case 3 : reed_text("disclam.txt"); break;
		case 4 : while(tut_menu()){} break;
		case 5 : reed_text("support.txt"); break;
		case 6 : while(mou_menu()){}; break;
		case 7 : reed_text("loadfont.txt"); break;
		case 8 : reed_text("simpsoft.txt"); break;
		case 10 : pick = 0; break;
	}
	display_switch = 0;
	return(pick);
}

int tut_menu(void)
{
	int pick,choice,i = 0,old_i = 13,moux = 0,mouy = 0;
		char lable[13][25] = {"simp_window\(\)","popup_window\(\)","unpopup_window\(\)","get_string\(\)",
		"clear_window\(\)","show_cursor\(\)","hide_cursor\(\)","write_window\(\)","read_text\(\)",
		"save_screen\(\)","load_screen\(\)","init_window\(\)","uninit_window\(\)"};

	if(display_switch)
	{
		popup_window(FUNG_WIN,20,5,40,19,2,2,14,6,1,8,0,0,0);
		read_text("fung.men",3);
		write_window(3,1," FUNGTION MENU ");
		save_screen(4);
	}
	else
	{
		load_screen(4);
	}
	save_screen(0);
	moushow();
	for(;;)
	{
		choice = 0;
		if(mouposition(&moux,&mouy))
		{
			if((moux > 21) & (moux < 46))
			{
				i = mouy - 6;
			}
		}
		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 13; break;
				case ENTER : choice = 1; break;
				case CURSOR_UP : i = i - 1; break;
				case CURSOR_DN : i = i + 1; break;
			}
		}
		if(i < 0)
		{
			i = 0;
		}
		if(i > 12)
		{
			i = 12;
		}
		if(old_i != i)
		{
			mouhide();
			old_i = i;
			load_screen(0);
			simp_window(21,6 + i,21 + strlen(lable[i]) + 1,6 + i,0,2,4,3,1,8,0,0,0);
			write_window(2,1,"%s",lable[i]);
			moushow();
		}
		if(moubuttonpressed(LEFTBUTTON))
		{
			if((moux > 21) & (moux < 46) & (mouy > 5) & (mouy < 19))
			{
				choice = 1;
			}
			else
			{
				choice = 13;
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);
	pick = 1;
	if(choice == 1)
	{
		choice = i;
	}
	pick = 1;
	switch(choice)
	{
		case 0 : reed_text("fung1.txt"); break;
		case 1 : reed_text("fung2.txt"); break;
		case 2 : reed_text("fung3.txt"); break;
		case 3 : reed_text("fung4.txt"); break;
		case 4 : reed_text("fung5.txt"); break;
		case 5 : reed_text("fung6.txt"); break;
		case 6 : reed_text("fung7.txt"); break;
		case 7 : reed_text("fung8.txt"); break;
		case 8 : reed_text("fung9.txt"); break;
		case 9 : reed_text("fung10.txt"); break;
		case 10 : reed_text("fung11.txt"); break;
		case 11 : reed_text("fung12.txt"); break;
		case 12 : reed_text("fung13.txt"); break;
		case 13 : pick = 0; break;
	}
	display_switch = 0;
	return(pick);
}


int mou_menu(void)
{
	int pick,choice,i = 0,old_i = 13,moux = 0,mouy = 0;
		char lable[10][25] = {"mouinstalled\(\)","moureset\(\)",
		"moubuttonpressed\(\)","mouhide\(\)","moushow\(\)",
		"moucursortype\(\)","mouseposition\(\)","mouposition\(\)",
		"mousetmaxposition\(\)","moubuttonreleased\(\)"};

	if(display_switch)
	{
		popup_window(FUNG_WIN,18,5,42,16,2,2,14,6,1,8,0,0,0);
		read_text("mou.men",3);
		write_window(5,1," MOUSE MENU ");
		save_screen(4);
	}
	else
	{
		load_screen(4);
	}
	save_screen(0);
	moushow();
	for(;;)
	{
		choice = 0;
		if(mouposition(&moux,&mouy))
		{
			moushow();
			if((moux > 19) & (moux < 43))
			{
				i = mouy - 6;
			}
		}
		if(bioskey(1) | (mou_switch == 0))
		{
			switch(bioskey(0))
			{
				case ESC : choice = 12; break;
				case ENTER : choice = 1; break;
				case CURSOR_UP : i = i - 1; break;
				case CURSOR_DN : i = i + 1; break;
			}
		}
		if(i < 0)
		{
			i = 0;
		}
		if(i > 9)
		{
			i = 9;
		}
		if(old_i != i)
		{
			mouhide();
			old_i = i;
			load_screen(0);
			simp_window(19,6 + i,19 + strlen(lable[i]) + 1,6 + i,0,2,4,3,1,8,0,0,0);
			write_window(2,1,"%s",lable[i]);
			moushow();
		}
		if(moubuttonpressed(LEFTBUTTON))
		{
			if((moux > 18) & (moux < 43) & (mouy > 5) & (mouy < 16))
			{
				choice = 1;
			}
			else
			{
				choice = 12;
			}
		}
		if(choice != 0)
		{
			break;
		}
	}
	mouhide();
	load_screen(0);
	pick = 1;
	if(choice == 1)
	{
		choice = i;
	}
	pick = 1;
	switch(choice)
	{
		case 0 : reed_text("fung14.txt"); break;
		case 1 : reed_text("fung15.txt"); break;
		case 2 : reed_text("fung16.txt"); break;
		case 3 : reed_text("fung19.txt"); break;
		case 4 : reed_text("fung20.txt"); break;
		case 5 : reed_text("fung17.txt"); break;
		case 6 : reed_text("fung21.txt"); break;
		case 7 : reed_text("fung22.txt"); break;
		case 8 : reed_text("fung23.txt"); break;
		case 9 : reed_text("fung24.txt"); break;
		case 10 : reed_text("fung25.txt"); break;
		case 12 : pick = 0; break;
	}
	display_switch = 0;
	return(pick);
}

int demo_popup(void)
{
	long int free_space,block = 4056L,convert = 1L,temp_num;
	struct dfree space;
	char drive[3] = "C",int_data[7];
	unsigned char drive_num;
	int i,x,y,fore,back,done = 0;
	unsigned int num_file;

	popup_window(DEMO_TEXT,10,5,70,20,2,2,15,6,1,8,0,0,0);
	write_window(25,16," HIT ANY KEY ");
	window(12,6,70,20);
	read_text("capdemo.txt",2);
/*************************************************************************

	this code asks for a drive letter and selects that drive
	for the utilitie files checking to see if there is enough
	memory

*************************************************************************/

	popup_window(ENTER_WIN,20,10,60,12,1,2,14,2,1,8,0,0,0);
	write_window(3,2,"Enter drive letter :");
	if(get_string(drive," ","u",24,2,1,1) == 1)
	{
		unpopup_window(ENTER_WIN);
		unpopup_window(DEMO_TEXT);
		return(0);
	}
	switch(drive[0])
	{
		case 'A' : drive_num = 1; break;
		case 'B' : drive_num = 2; break;
		case 'C' : drive_num = 3; break;
		case 'D' : drive_num = 4; break;
		case 'E' : drive_num = 5; break;
		case 'F' : drive_num = 6; break;
		case 'G' : drive_num = 7; break;
		default : drive_num = 0; break;
	}
	getdfree(drive_num,&space);
	free_space = (convert * space.df_avail * space.df_bsec * space.df_sclus);
	temp_num = (free_space / block) - 5;
	if(temp_num < 0)
	{
		popup_window(0,1,25,80,25,0,0,14,4,0,0,0,0,0);
		write_window(3,1,"Not enough disk space !");
		bioskey(0);
		unpopup_window(0);
		unpopup_window(ENTER_WIN);
		unpopup_window(DEMO_TEXT);
		return(1);
	}

/****************************************************************************/

	clear_window(0);
	write_window(3,2,"Enter number of popups:");
	if(temp_num > 65530L)
	{
		temp_num = 65530L;
	}
	ltoa(temp_num,int_data,10);
	show_cursor();
	while(done == 0)
	{

		if(get_string(int_data,"     ","99999",27,2,1,1) == 1)
		{
			hide_cursor();
			unpopup_window(9);
			unpopup_window(8);
			return(0);
		}
		num_file = atoi(int_data);
		if(temp_num < num_file)
		{
			clear_window(0);
			write_window(3,2,"To many popups !");
			bioskey(0);
			clear_window(0);
			write_window(3,2,"Enter number of popups:");
			ltoa(temp_num,int_data,10);
		}
		else
		{
			done = 1;
		}
	}
	hide_cursor();
	unpopup_window(9);
	unpopup_window(8);
	creat("win.tem",S_IREAD|S_IWRITE);
	creat("screen.tem",S_IREAD|S_IWRITE);
	system("copy win.dat win.tem > font.tem");
	system("copy screen.dat screen.tem > font.tem");
	uninit_window();
	if(init_window(0,0,drive) == 0)
	{
		for(i = 1;i < num_file;i++)
		{
			x = (random(69) + 3);
			y = (random(20) + 2);
			fore = random(16);
			back = random(8);
			popup_window(i,x,y,x + 7,y + 2,1,2,fore,back,1,8,0,0,0);
			write_window(3,2,"%d",i);
		}
		popup_window(num_file,35,10,42,12,1,2,14,12,1,8,0,0,0);
		write_window(3,2,"%d",num_file);
		done = 0;
		while(done == 0)
		{
			for(i = 500;i < 800;i++)
			{
				sound(i);
				delay(5);
			}
			if(bioskey(1))
			{
				break;
			}
			for(i = 800;i > 500;i--)
			{
				sound(i);
				delay(5);
			}
			if(bioskey(1))
			{
				bioskey(0);
				break;
			}
		}
		nosound();
		for(i = num_file; i > 0;i--)
		{
			unpopup_window(i);
		}
		uninit_window();
	}
	init_window(12,5,"");
	system("copy win.tem win.dat > font.tem");
	system("copy screen.tem screen.dat > font.tem");
	remove("win.tem");
	remove("screen.tem");
	display_switch = 0;
	return(0);
}

int shad_demo(void)
{
	int fore,back,i;

	popup_window(DEMO_TEXT,10,5,70,20,2,2,14,6,1,8,0,0,0);
	write_window(25,16," HIT ANY KEY ");
	window(16,9,70,20);
	read_text("shaddemo.txt",2);
	for(i = 0;i < 3;i++)
	{
		popup_window(11,20,10,63,15,2,i,14,2,1,8,0,0,0);
		switch(i)
		{
			case 0 : write_window(3,3,"This is the 0 or NO_SHADOW style."); break;
			case 1 : write_window(3,3,"This is the 1 or WIDE_SHADOW style"); break;
			case 2 : write_window(3,3,"This is the 2 or NARROW_SHADOW style"); break;
		}
		write_window(15,6," HIT ANY KEY ");
		bioskey(0);
		unpopup_window(11);
	}
	for(i = 1;i < 5;i++)
	{
		popup_window(11,20,10,63,15,2,1,14,2,i,8,0,0,0);
		switch(i)
		{
			case 1 : write_window(3,3,"This is the 1 or LOWER LEFT location"); break;
			case 2 : write_window(3,3,"This is the 2 or UPPER_LEFT location"); break;
			case 3 : write_window(3,3,"This is the 3 or LOWER_RIGHT location"); break;
			case 4 : write_window(3,3,"This is the 4 or UPPER_RIGHT location"); break;
		}
		write_window(15,6," HIT ANY KEY ");
		bioskey(0);
		unpopup_window(11);
	}
	for(;;)
	{
		fore = random(16);
		back = random(8);
		popup_window(11,20,10,63,15,2,2,14,2,1,fore,back,0,0);
		write_window(15,6," HIT ANY KEY ");
		write_window(6,3,"These are the diffrent colors that");
		write_window(11,4,"you can use for shadows.");
		delay(700);
		if(bioskey(1))
		{
			bioskey(0);
			unpopup_window(11);
			break;
		}
	}
	unpopup_window(DEMO_TEXT);
	display_switch = 0;
	return(0);
}

int boarder_demo(void)
{
	int i,char_boarder;

	save_screen(5);
	system(font_string);
	load_screen(5);
	popup_window(DEMO_TEXT,10,5,70,20,2,2,14,6,1,8,0,0,0);
	write_window(25,16," HIT ANY KEY ");
	window(16,10,70,20);
	read_text("boarder.txt",2);
	for(i = 0;i <5;i++)
	{
		popup_window(11,20,10,60,15,i,2,14,2,1,8,0,0,0);
		switch(i)
		{
			case 0 : write_window(3,3,"This is the 0 or NO_BOARDER style."); break;
			case 1 : write_window(3,3,"This is the 1 or SINGLE_BOARDER style"); break;
			case 2 : write_window(3,3,"This is the 2 or DOUBLE_BOARDER style"); break;
			case 3 : write_window(3,3,"This is the 3 or SIG_DUB_BOARDER style"); break;
			case 4 : write_window(3,3,"This is the 4 or DUB_SIG_BOARDER style"); break;
		}
		write_window(15,6," HIT ANY KEY ");
		bioskey(0);
	}
	for(;;)
	{
		char_boarder = random(255);
		if(char_boarder < 15)
		{
			char_boarder = char_boarder + 15;
		}
		popup_window(11,20,10,60,15,5,2,14,2,1,8,0,char_boarder,0);
		write_window(15,3," HIT ANY KEY ");
		delay(700);
		if(bioskey(1))
		{
			bioskey(0);
			unpopup_window(11);
			break;
		}
	}
	unpopup_window(DEMO_TEXT);
	display_switch = 0;
	return(0);
}

int enter_demo(void)
{
	int int_data = 0,i;
	double float_data = 0.0;
	char enter_string[30] = "";

	popup_window(DEMO_TEXT,10,5,70,20,2,2,15,6,1,8,0,0,0);
	write_window(25,16," HIT ANY KEY ");
	window(18,10,70,20);
	read_text("entdemo.txt",2);
	show_cursor();
	for(i = 0;i < 4;i++)
	{
		popup_window(11,20,10,60,15,2,2,14,2,1,0,8,0,0);
		switch(i)
		{
			case 0 : write_window(3,3,"Enter Int :");
					strcpy(enter_string,"0");
					get_string(enter_string,"   ","#999",16,3,1,1);
					int_data = atoi(enter_string);
					write_window(3,4,"You entered %d",int_data);
					break;
			case 1 : write_window(3,3,"Enter Float :");
					strcpy(enter_string,"0.0");
					get_string(enter_string,"       ","FFFFFFF",18,3,1,1);
					float_data = atof(enter_string);
					write_window(3,4,"You entered %3.4f",float_data);
					break;
			case 2 : write_window(3,3,"Enter String :");
					get_string(enter_string,"          --        ","**********  ********",18,3,1,0);
					write_window(3,4,"You entered %s",enter_string);
					break;
			case 3 : write_window(3,3,"Enter date :");
					get_string(enter_string,"  /  /  ","99 99 99",16,3,0,0);
					write_window(3,4,"You enterd %s",enter_string);
					break;
		}
		write_window(15,5," HIT ANY KEY ");
		bioskey(0);
		clear_window(0);
	}
	hide_cursor();
	unpopup_window(11);
	unpopup_window(DEMO_TEXT);
	display_switch = 0;
	return(0);
}

/***************************************************************************

	this modual reads a text file and displays it on the screen

**************************************************************************/

void reed_text(char *file_name)
{
	popup_window(EDIT_WIN,1,1,80,25,1,0,14,6,0,0,0,0,0);
	write_window(35,1," %s ",file_name);
	write_window(32,25," PGUP/PGDN ESC ");
	read_text(file_name,0);
	unpopup_window(EDIT_WIN);
	display_switch = 0;
}

int read_text_demo(void)
{
	char file_name[255] = "";

	popup_window(DEMO_TEXT,10,5,70,20,2,2,14,6,1,8,0,0,0);
	write_window(25,16," HIT ANY KEY ");
	window(19,10,70,20);
	read_text("readtext.txt",2);
	popup_window(ENTER_WIN,10,10,70,12,1,2,14,2,1,8,0,0,0);
	write_window(3,2,"Enter File Name: ");
	if(get_string(file_name,"                                        ",
			"**************************************",20,2,1,1) == 1)
	{
		unpopup_window(ENTER_WIN);
		unpopup_window(DEMO_TEXT);
		return(0);
	}
	reed_text(file_name);
	unpopup_window(ENTER_WIN);
	unpopup_window(DEMO_TEXT);
	return(0);
}

