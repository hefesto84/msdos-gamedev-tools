#include <stdarg.h>
#include <dos.h>
#include <mem.h>
#include <stdio.h>
#include <string.h>
#include <alloc.h>
#include <conio.h>
#include <stdlib.h>


void main(int argc,char *argv[])
{
	char *char_buff;
	unsigned int handle;
	unsigned int error;
	unsigned int seg;
	unsigned int off;
	unsigned int file_seg;
	unsigned int file_off;
	char *file_name;

	if((char_buff = (char*)malloc(4096)) == NULL)
	{
		cprintf("Not enough memory!");
		exit(1);
	}
	else
	{
		if((file_name = (char*)malloc(256)) == NULL)
		{
			cprintf("Not enough memory!");
			free(char_buff);
			exit(1);
		}
	}
	strcpy(file_name,argv[1]);
	asm	mov ax,ds;
	asm	mov seg,ax;
	asm	mov file_seg,ax;
	asm	mov ax,char_buff;
	asm	mov off,ax;
	asm	mov ax,file_name;
	asm	mov file_off,ax;
	asm	mov ax,file_seg;
	asm	mov dx,file_off;
	asm	push ds;
	asm	mov ds,ax;
	asm	mov al,0x02;
	asm	mov ah,0x3d;
	asm	int 0x21;
	asm	pop ds;
	asm	jnc cont1;
	asm	mov error,ax;
	free(file_name);
	free(char_buff);
	cprintf("No file found!");
	exit(1);
	cont1:
	asm	mov handle,ax;
	asm	mov bx,ax;
	asm	mov cx,4096;
	asm	mov dx,off;
	asm	mov ax,seg;
	asm	push ds;
	asm	mov ds,ax;
	asm	mov ah,0x3f;
	asm	int 0x21;
	asm	pop ds;
	asm	jnc cont2;
	asm	mov error,ax;
	free(char_buff);
	free(file_name);
	asm	mov ah,0x3e;
	asm	mov bx,handle;
	asm	int 0x21;
	asm	jnc cont3;
	asm	mov error,ax;
	cprintf("Read error!");
	free(char_buff);
	free(file_name);
	exit(1);
	cont2:
	asm	mov ah,0x3e;
	asm	mov bx,handle;
	asm	int 0x21;
	asm	jnc cont3;
	asm	mov error,ax;
	free(char_buff);
	free(file_name);
	cprintf("Can't close file!");
	exit(1);
	cont3:
	asm	mov bh,0x10;
	asm	mov bl,0x00;
	asm	mov dx,0x00;
	asm	mov cx,0xff;
	asm	mov ax,seg;
	asm	push es;
	asm	mov es,ax;
	asm	push bp;
	asm	mov ax,off;
	asm	mov bp,ax;
	asm	mov ah,0x11;
	asm	mov al,0x10;
	asm	int 0x10;
	asm	pop bp;
	asm	pop es;
	free(char_buff);
	free(file_name);
}
