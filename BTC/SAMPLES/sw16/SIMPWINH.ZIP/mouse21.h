/* simple windows copyright 1994,1995,1996 by bruce r. o'banion */

int mouinstalled(void);
void moureset(void);
int moubuttonpressed(int);
void mouhide(void);
void moushow(void);
void mousetposition(int,int);
int mouposition(int*,int*);
int mousetmaxposition(int,int,int,int);
int moubuttonrelease(int);
int loadcurs(void*,int);
void moucursortype(unsigned int type);
int mou_get_adapter(void);
int mou_get_mode(int *col,int *row);

#define LEFTBUTTON     0
#define RIGHTBUTTON    1
#define MIDBUTTON      2





