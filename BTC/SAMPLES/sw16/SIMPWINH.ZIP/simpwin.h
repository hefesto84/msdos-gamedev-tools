/* Simple Windows 1.5 Copyright By Bruce R. O'Banion */
/* Header File */

/* boarder defines */
# define NO_BOARDER 0
# define SINGLE_BOARDER 1
# define DOUBLE_BOARDER 2
# define SIG_DUB_BOARDER 3
# define DUB_SIG_BOARDER 4
# define ANY_BOARDER 5

/* shadow style defines */
# define NO_SHADOW 0
# define NARROW_SHADOW 2
# define WIDE_SHADOW 1

/* shadow location defines */
# define LOWER_LEFT 1
# define UPPER_LEFT 2
# define LOWER_RIGTH 3
# define UPPER_RIGHT 4

/* word defines */
# define ON 1
# define OFF 0
# define YES 1
# define NO 0

/* note defines */
# define _A 1
# define _Bb 2
# define _B 3
# define _C 4
# define _Cs 5
# define _D 6
# define _Eb 7
# define _E 8
# define _F 9
# define _Fs 10
# define _G 11
# define _Ab 12

/* cord type defines */
# define _MAJOR "M"
# define _MINOR "m"
# define _7TH "7"
# define _MAJOR_7TH "M7"
# define _MINOR_7TH "m7"


/* call window */
int simp_window(int l,int t,int r,int b,int boarder,int shad,int forground,
	 int background,int shadlocate,int shadforground,int shadbackground,
	 int boarderchar,int fillchar);

/* call popup window */
int popup_window(int filenum,int l,int t,int r,int b,int boarder,int shad,
	int forground,int background,int shadlocate,int shadforground,
	int shadbackground,int boarderchar,int fillchar);

/* call unpopup window */
int unpopup_window(int filenum);

/* save window info */
int save_window_data(int filenum);

/* load window info */
int load_window_data(int filenum);

/* initialize windows */
int init_window(int win,int menu,int screen,char *drive,int port);

/* uninitialize windows */
int uninit_window(void);

/* get intigers */
int get_int(int *data,int size,int x,int y);

/* get long intigers */
int get_long(long int *data,int size,int x,int y);

/* get strings */
int get_string(char *data,char *format,char *mask,int x,int y,int strip,int disply);

/* get choice */
int get_choice(int x,int y,char *choice);

/* get intiger date */
int get_int_date(int *date,int x,int y);

/* full edit field */
int edit_string(char *data,char *format,int x,int y,char *mask);

/* draw horizontal line */
int draw_horizontal_line(int start,int mid,int end,int startx,int endx,int y);

/* draw vertical line */
int draw_vertical_line(int start,int mid,int end,int x,int starty,int endy);

/* sound a tone */
int tone(int octive,int note,int size);

/* sound a four note cord */
int cord(int note,int size,char *type);

/* set_tempo */
void set_tempo(int temposet);

/* play song file */
int playsong(int temposet,char *filename);

/* hide cursor */
void hide_cursor(void);

/* show cursor */
void show_cursor(void);

/* draw print window */
int print_window(int l,int t,int r,int b,int boarder,int boarderchar);

/* formated print */
int print_printf(int x,int y,char *data,...);

/* print character */
int print_putch(int x,int y,int pchar);

/* print horizontal line */
int print_horizontal_line(int start,int mid,int end,int startx,int endx,int y);

/* print vertical line */
int print_vertical_line(int start,int mid,int end,int x,int starty,int endy);

/* clear print buffer */
int clear_print_buff(void);

/* print page from buffer */
int print_buff(void);

/* print a character */
int print_char(unsigned char pchar);

/* write in window */
int write_window(int x,int y,char *data,...);

/* clear window */
int clear_window(int cchar);

/* make a menu in window */
int make_menu(int filenum,int lines,...);

/* call menu */
int call_menu(int filenum,int x,int y);

/* save menu data to file */
int save_menu(int filenum);

/* load menu data from file */
int load_menu(int filenum);

/* make a window don't display */
int make_window(int filenum,int l,int t,int r,int b,int boarder,int shad,int forground,
	int background,int shadlocate,int shadforground,int shadbackground,
	int boarderchar,int fillchar);

/* call and display made window */
int call_window(int filenum);

/* uncall a made window */
int uncall_window(int filenum);

/* save a current screen */
int save_screen(int filenum);

/* load a screen */
int load_screen(int filenum);

/* move a current window */
int move_window(int x,int y);

/* move cursor in current window */
int move_cursor(int x,int y);


/* save screen to buffer */
void save_screen_buff(void);

/* load screen from buffer */
void load_screen_buff(void);

/* load menu text */
int load_menu_text(char *filename);

/* load text */
int load_text(int,char *filename);


/* load window file */
int load_win_data(char *filename);

/* load print from */
int load_form(int filenum,char *filename);

/* save form data */
int save_form(int filenum,char *filename);

/* load screen form */
int load_screen_form(int filenum,char *filename);


/* write a block to a file */
int write_file(void *buff,char *filename,unsigned int size,unsigned long int startbyte);

/* read a block from a file */
int read_file(void *buff,char *filename,unsigned int size,unsigned long int startbyte);

/* write a block from one file to another */
int file_to_file(void *buff,char *sourse,long int sorsestartbyte,char * destination,
long int deststartbyte,int size);

/* creat a file if none exists */
int creat_file(char *filename);

/* copy a file to another file */
int copy_file(char *sourse,char *destination);

/* read a directory */
int read_directory(char *filename,int size,char *directory);

/* read a text file */
int read_text(char *filename,int wrap);


